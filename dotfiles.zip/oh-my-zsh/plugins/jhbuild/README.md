## JHBuild
**Maintainer:** [Miguel Vaello](https://github.com/miguxbe)

This plugin adds some jhbuild aliases and increase the completion function provided by zsh.
