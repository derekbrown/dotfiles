#Dotfiles

##What is Dotfiles?
Dotfiles is a repository filled with my configurations for various tools I use during development: zsh, git, etc.

##How do I get Dotfiles running locally?
1. Fork this repository.
2. Clone it to your ~ directory.
3. Run the command `sh .make.sh` from your local dotfiles directory.
4. Enjoy!

##How do I develop within Dotfiles?
1. You don't. Fork this repository.

##Todos
1. Add linking for Sublime settings.
2. Build more robust install script.

